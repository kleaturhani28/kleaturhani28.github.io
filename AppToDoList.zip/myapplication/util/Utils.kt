package com.programmazionemobile.myapplication.util

val <T> T.exhaustive: T
    get() = this