import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-pagina-voucher.dart';
import 'package:myapp/routes.dart';

class MobileStartHomeWelfareCard extends StatefulWidget {
  const MobileStartHomeWelfareCard({Key? key}) : super(key: key);

  @override
  _MobileStartHomeWelfareCardState createState() => _MobileStartHomeWelfareCardState();
}

class _MobileStartHomeWelfareCardState extends State<MobileStartHomeWelfareCard> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    if (index == 2) {
      Navigator.push(context,
        MaterialPageRoute(builder: (context) => PaginaVoucher()),
      );
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery
        .of(context)
        .size
        .width / baseWidth;
    double ffem = fem * 0.97;

    return SingleChildScrollView( // Aggiunto il SingleChildScrollView qui

      child: Container(
        width: double.infinity,
        child: Container(
          // mobilestarthomewelfarecardjrX (0:657)
          width: double.infinity,
          height: 1505 * fem,
          decoration: BoxDecoration(
            color: Color(0xfff5f8ff),
          ),
          child: Stack(
            children: [
              Positioned(
                // autogroupaoro935 (FKEUA1b82riXZDPcMfAoro)
                left: 0 * fem,
                top: 92 * fem,
                child: Container(
                  width: 626 * fem,
                  height: 1288 * fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // autogrouphfgjQjh (FKEUik9aZCVojTtLAVhfGj)
                        margin: EdgeInsets.fromLTRB(
                            0 * fem, 0 * fem, 0 * fem, 20 * fem),
                        width: 567.97 * fem,
                        height: 1016 * fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // frame2966stB (0:662)
                              left: 18 * fem,
                              top: 189 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 467 * fem,
                                  height: 70 * fem,
                                  child: Image.asset(
                                    'assets/page-1/images/frame-2966.png',
                                    width: 467 * fem,
                                    height: 70 * fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // buoniacquistoo9Z (0:664)
                              left: 20 * fem,
                              top: 142 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 121 * fem,
                                  height: 25 * fem,
                                  child: Text(
                                    'Buoni acquisto',
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 18 * ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xff22408b),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // voucherconsigliatiFXM (0:665)
                              left: 20 * fem,
                              top: 462 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 156 * fem,
                                  height: 25 * fem,
                                  child: Text(
                                    'Voucher consigliati',
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 18 * ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xff22408b),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // cardvoucherjSX (0:666)
                              left: 19 * fem,
                              top: 508 * fem,
                              child: Container(
                                width: 160 * fem,
                                height: 213 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xffeeeeee)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(12 * fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x0c000000),
                                      offset: Offset(0 * fem, 0 * fem),
                                      blurRadius: 9.5 * fem,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  // frame2648nfh (0:667)
                                  width: 161 * fem,
                                  height: 205 * fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Container(
                                        // group26477CB (0:668)
                                        margin: EdgeInsets.fromLTRB(
                                            0 * fem, 0 * fem, 0 * fem, 8 * fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .center,
                                          children: [
                                            Container(
                                              // pexelssulimansallehi21281652de (0:670)
                                              padding: EdgeInsets.fromLTRB(
                                                  1 * fem, 1 * fem, 1 * fem,
                                                  0 * fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration(
                                                color: Color(0xfff3f3f3),
                                              ),
                                              child: Align(
                                                // pexelssulimansallehi212816529P (0:671)
                                                alignment: Alignment
                                                    .bottomCenter,
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 106 * fem,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xfff3f3f3),
                                                      image: DecorationImage(
                                                        fit: BoxFit.cover,
                                                        image: AssetImage(
                                                          'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-wsM.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),

                                             Container(
                                              // frame60eLX (0:673)
                                              margin: EdgeInsets.fromLTRB(
                                                  1 * fem, 0 * fem, 1 * fem,
                                                  0 * fem),
                                              padding: EdgeInsets.fromLTRB(
                                                  12 * fem, 4 * fem, 12 * fem,
                                                  4 * fem),
                                              width: double.infinity,
                                              height: 66 * fem,
                                              decoration: BoxDecoration(
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.only(
                                                  bottomRight: Radius.circular(
                                                      12 * fem),
                                                  bottomLeft: Radius.circular(
                                                      12 * fem),
                                                ),
                                              ),
                                              child: Container(
                                                // frame119wqR (0:674)
                                                width: 109 * fem,
                                                height: 43 * fem,

                                                  child: Column(
                                                    verticalDirection: VerticalDirection.down,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment
                                                      .start,
                                                  children: [
                                                    Container(
                                                      // romafWX (0:675)
                                                      // margin: EdgeInsets
                                                      //     .fromLTRB(
                                                      //     0 * fem, 0 * fem,
                                                      //     0 * fem, 4 * fem),
                                                      margin: EdgeInsets
                                                       .fromLTRB(
                                                       0 * fem, 0 * fem,
                                                       0 * fem, 1 * fem),

                                                      child: Text(
                                                        'Roma',
                                                        style: SafeGoogleFont(
                                                          'Nunito',
                                                          fontSize: 10 * ffem,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          height: 2 * ffem /
                                                              fem,
                                                          color: Color(
                                                              0xff091125),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      // weekendrelaxZbu (0:676)
                                                      'Weekend Relax\n',
                                                      style: SafeGoogleFont(
                                                        'Nunito',
                                                        fontSize: 15 * ffem,
                                                        fontWeight: FontWeight
                                                            .w700,
                                                        height: 1.2666666667 *
                                                            ffem / fem,
                                                        letterSpacing: -0.0450000018 *
                                                            fem,
                                                        color: Color(
                                                            0xff091125),
                                                      ),
                                                    ),
                                                  ],
                                                ),

                                              ),

                                            ),

                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame2646Uym (0:678)
                                        margin: EdgeInsets.fromLTRB(
                                            9 * fem, 0 * fem, 58 * fem,
                                            0 * fem),
                                        width: double.infinity,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment
                                              .start,
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment: CrossAxisAlignment
                                              .center,

                                          children: [
                                            Container(
                                              // maskgroup1io (0:679)
                                             /* margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 6 * fem,
                                                  0 * fem),*/
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 2 * fem,
                                                  0 * fem),
                                              width: 24 * fem,
                                              height: 24 * fem,
                                              child: Image.asset(
                                                'assets/page-1/images/mask-group-q5h.png',
                                                width: 24 * fem,
                                                height: 24 * fem,
                                              ),
                                            ),
                                            Container(
                                              // hamburgerdibovinoXSF (0:682)
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 1 * fem, 0 * fem,
                                                  0 * fem),
                                              child: Text(
                                                'TantoSvago',
                                                style: SafeGoogleFont(
                                                  'Nunito',
                                                  fontSize: 12 * ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3625 * ffem / fem,
                                                  color: Color(0xff8a94a6),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // cardvoucherpRM (0:683)
                              left: 196 * fem,
                              top: 508 * fem,
                              child: Container(
                                width: 160 * fem,
                                height: 213 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xffeeeeee)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(12 * fem),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x0c000000),
                                      offset: Offset(0 * fem, 0 * fem),
                                      blurRadius: 9.5 * fem,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  // frame2648giT (0:684)
                                  width: 161 * fem,
                                  height: 205 * fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Container(
                                        // group2647d7u (0:685)
                                        margin: EdgeInsets.fromLTRB(
                                            0 * fem, 0 * fem, 0 * fem, 8 * fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .center,
                                          children: [
                                            Container(
                                              // pexelssulimansallehi21281652de (0:687)
                                              padding: EdgeInsets.fromLTRB(
                                                  1 * fem, 1 * fem, 1 * fem,
                                                  0 * fem),
                                              width: double.infinity,
                                              decoration: BoxDecoration(
                                                color: Color(0xfff3f3f3),
                                              ),
                                              child: Align(
                                                // pexelssulimansallehi21281652sn (0:688)
                                                alignment: Alignment
                                                    .bottomCenter,
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 106 * fem,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xfff3f3f3),
                                                      image: DecorationImage(
                                                        fit: BoxFit.cover,
                                                        image: AssetImage(
                                                          'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-w8B.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame60Bod (0:690)
                                              margin: EdgeInsets.fromLTRB(
                                                  1 * fem, 0 * fem, 1 * fem,
                                                  0 * fem),
                                              padding: EdgeInsets.fromLTRB(
                                                  12 * fem, 4 * fem, 12 * fem,
                                                  4 * fem),
                                              width: double.infinity,
                                              height: 66 * fem,
                                              decoration: BoxDecoration(
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.only(
                                                  bottomRight: Radius.circular(
                                                      12 * fem),
                                                  bottomLeft: Radius.circular(
                                                      12 * fem),
                                                ),
                                              ),
                                              child: Container(
                                                // frame119U23 (0:691)
                                                width: 109 * fem,
                                                height: 43 * fem,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment
                                                      .start,
                                                  children: [
                                                    Container(
                                                      // romaCyd (0:692)
                                                      /*margin: EdgeInsets
                                                          .fromLTRB(
                                                          0 * fem, 0 * fem,
                                                          0 * fem, 4 * fem),*/
                                                      margin: EdgeInsets
                                                          .fromLTRB(
                                                          0 * fem, 0 * fem,
                                                          0 * fem, 1 * fem),
                                                      child: Text(
                                                        'Roma',
                                                        style: SafeGoogleFont(
                                                          'Nunito',
                                                          fontSize: 10 * ffem,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          height: 2 * ffem /
                                                              fem,
                                                          color: Color(
                                                              0xff091125),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      // weekendrelaxgP1 (0:693)
                                                      'Weekend Relax\n',
                                                      style: SafeGoogleFont(
                                                        'Nunito',
                                                        fontSize: 15 * ffem,
                                                        fontWeight: FontWeight
                                                            .w700,
                                                        height: 1.2666666667 *
                                                            ffem / fem,
                                                        letterSpacing: -0.0450000018 *
                                                            fem,
                                                        color: Color(
                                                            0xff091125),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame2646oTd (0:695)
                                        margin: EdgeInsets.fromLTRB(
                                            9 * fem, 0 * fem, 58 * fem,
                                            0 * fem),
                                        width: double.infinity,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment: CrossAxisAlignment
                                              .center,
                                          children: [
                                            Container(
                                              // maskgroupi4o (0:696)
                                              /*margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 6 * fem,
                                                  0 * fem),*/
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 2 * fem,
                                                  0 * fem),
                                              width: 24 * fem,
                                              height: 24 * fem,
                                              child: Image.asset(
                                                'assets/page-1/images/mask-group-yEw.png',
                                                width: 24 * fem,
                                                height: 24 * fem,
                                              ),
                                            ),
                                            Container(
                                              // hamburgerdibovinop7q (0:699)
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 1 * fem, 0 * fem,
                                                  0 * fem),
                                              child: Text(
                                                'TantoSvago',
                                                style: SafeGoogleFont(
                                                  'Nunito',
                                                  fontSize: 12 * ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3625 * ffem / fem,
                                                  color: Color(0xff8a94a6),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // frame5071Joh (0:700)
                              left: 20 * fem,
                              top: 738 * fem,
                              child: Container(
                                width: 337 * fem,
                                height: 213 * fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // cardvoucher2jh (0:701)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 17 * fem, 0 * fem),
                                      width: 160 * fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Color(0xffeeeeee)),
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(
                                            12 * fem),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x0c000000),
                                            offset: Offset(0 * fem, 0 * fem),
                                            blurRadius: 9.5 * fem,
                                          ),
                                        ],
                                      ),
                                      child: Container(
                                        // frame2648XRZ (0:702)
                                        width: 161 * fem,
                                        height: 205 * fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .start,
                                          children: [
                                            Container(
                                              // group2647ULo (0:703)
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 0 * fem,
                                                  8 * fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment
                                                    .center,
                                                children: [
                                                  Container(
                                                    // pexelssulimansallehi21281652de (0:705)
                                                    padding: EdgeInsets
                                                        .fromLTRB(
                                                        1 * fem, 1 * fem,
                                                        1 * fem, 0 * fem),
                                                    width: double.infinity,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xfff3f3f3),
                                                    ),
                                                    child: Align(
                                                      // pexelssulimansallehi21281652jG (0:706)
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 106 * fem,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(
                                                                0xfff3f3f3),
                                                            image: DecorationImage(
                                                              fit: BoxFit.cover,
                                                              image: AssetImage(
                                                                'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame60RQT (0:708)
                                                    margin: EdgeInsets.fromLTRB(
                                                        1 * fem, 0 * fem,
                                                        1 * fem, 0 * fem),
                                                    padding: EdgeInsets
                                                        .fromLTRB(
                                                        12 * fem, 4 * fem,
                                                        12 * fem, 4 * fem),
                                                    width: double.infinity,
                                                    height: 66 * fem,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xffffffff),
                                                      borderRadius: BorderRadius
                                                          .only(
                                                        bottomRight: Radius
                                                            .circular(12 * fem),
                                                        bottomLeft: Radius
                                                            .circular(12 * fem),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      // frame1197YB (0:709)
                                                      width: 109 * fem,
                                                      height: 43 * fem,
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        mainAxisSize: MainAxisSize.max,
                                                        crossAxisAlignment: CrossAxisAlignment
                                                            .start,
                                                        children: [
                                                          Container(
                                                            // roma3wd (0:710)
                                                            /*margin: EdgeInsets
                                                                .fromLTRB(
                                                                0 * fem,
                                                                0 * fem,
                                                                0 * fem,
                                                                4 * fem),*/
                                                            margin: EdgeInsets
                                                                .fromLTRB(
                                                                0 * fem, 0 * fem,
                                                                0 * fem, 1 * fem),
                                                            child: Text(
                                                              'Roma',
                                                              style: SafeGoogleFont(
                                                                'Nunito',
                                                                fontSize: 10 *
                                                                    ffem,
                                                                fontWeight: FontWeight
                                                                    .w500,
                                                                height: 2 *
                                                                    ffem / fem,
                                                                color: Color(
                                                                    0xff091125),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // weekendrelaxZ2o (0:711)
                                                            'Weekend Relax\n',
                                                            style: SafeGoogleFont(
                                                              'Nunito',
                                                              fontSize: 15 *
                                                                  ffem,
                                                              fontWeight: FontWeight
                                                                  .w700,
                                                              height: 1.2666666667 *
                                                                  ffem / fem,
                                                              letterSpacing: -0.0450000018 *
                                                                  fem,
                                                              color: Color(
                                                                  0xff091125),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // frame2646gNK (0:713)
                                              margin: EdgeInsets.fromLTRB(
                                                  9 * fem, 0 * fem, 58 * fem,
                                                  0 * fem),
                                              width: double.infinity,
                                              child: Row(

                                                mainAxisAlignment: MainAxisAlignment
                                                    .start,
                                                mainAxisSize: MainAxisSize.max,
                                                crossAxisAlignment: CrossAxisAlignment
                                                    .center,
                                                verticalDirection: VerticalDirection
                                                    .down,
                                                children: [
                                                  Container(
                                                    // maskgrouppUX (0:714)
                                                    /*margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 0 * fem,
                                                        6 * fem, 0 * fem),*/
                                                    margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 0 * fem, 2 * fem,
                                                        0 * fem),
                                                    width: 24 * fem,
                                                    height: 24 * fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/mask-group-33V.png',
                                                      width: 24 * fem,
                                                      height: 24 * fem,
                                                    ),
                                                  ),
                                                  Container(
                                                    // hamburgerdibovinoY9d (0:717)
                                                    margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 1 * fem,
                                                        0 * fem, 0 * fem),
                                                    child: Text(
                                                      'TantoSvago',
                                                      style: SafeGoogleFont(
                                                        'Nunito',
                                                        fontSize: 12 * ffem,
                                                        fontWeight: FontWeight
                                                            .w400,
                                                        height: 1.3625 * ffem /
                                                            fem,
                                                        color: Color(
                                                            0xff8a94a6),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // cardvouchereyM (0:718)
                                      width: 160 * fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Color(0xffeeeeee)),
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(
                                            12 * fem),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x0c000000),
                                            offset: Offset(0 * fem, 0 * fem),
                                            blurRadius: 9.5 * fem,
                                          ),
                                        ],
                                      ),
                                      child: Container(
                                        // frame2648ZKd (0:719)
                                        width: 161 * fem,
                                        height: 205 * fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .start,
                                          children: [
                                            Container(
                                              // group2647J2K (0:720)
                                              margin: EdgeInsets.fromLTRB(
                                                  0 * fem, 0 * fem, 0 * fem,
                                                  8 * fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment
                                                    .center,
                                                children: [
                                                  Container(
                                                    // pexelssulimansallehi21281652de (0:722)
                                                    padding: EdgeInsets
                                                        .fromLTRB(
                                                        1 * fem, 1 * fem,
                                                        1 * fem, 0 * fem),
                                                    width: double.infinity,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xfff3f3f3),
                                                    ),
                                                    child: Align(
                                                      // pexelssulimansallehi21281652ZD (0:723)
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: SizedBox(
                                                        width: double.infinity,
                                                        height: 106 * fem,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(
                                                                0xfff3f3f3),
                                                            image: DecorationImage(
                                                              fit: BoxFit.cover,
                                                              image: AssetImage(
                                                                'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-tVD.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame60H99 (0:725)
                                                    margin: EdgeInsets.fromLTRB(
                                                        1 * fem, 0 * fem,
                                                        1 * fem, 0 * fem),
                                                    padding: EdgeInsets
                                                        .fromLTRB(
                                                        12 * fem, 4 * fem,
                                                        12 * fem, 4 * fem),
                                                    width: double.infinity,
                                                    height: 66 * fem,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xffffffff),
                                                      borderRadius: BorderRadius
                                                          .only(
                                                        bottomRight: Radius
                                                            .circular(12 * fem),
                                                        bottomLeft: Radius
                                                            .circular(12 * fem),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      // frame119ZsM (0:726)
                                                      width: 109 * fem,
                                                      height: 43 * fem,
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        mainAxisSize: MainAxisSize.max,
                                                        verticalDirection: VerticalDirection.down,
                                                        crossAxisAlignment: CrossAxisAlignment
                                                            .start,

                                                        children: [
                                                          Container(
                                                            // romaJpw (0:727)
                                                            /*margin: EdgeInsets
                                                                .fromLTRB(
                                                                0 * fem,
                                                                0 * fem,
                                                                0 * fem,
                                                                4 * fem),*/
                                                            margin: EdgeInsets
                                                                .fromLTRB(
                                                                0 * fem, 0 * fem,
                                                                0 * fem, 1 * fem),
                                                            child: Text(
                                                              'Roma',
                                                              style: SafeGoogleFont(
                                                                'Nunito',
                                                                fontSize: 10 *
                                                                    ffem,
                                                                fontWeight: FontWeight
                                                                    .w500,
                                                                height: 2 *
                                                                    ffem / fem,
                                                                color: Color(
                                                                    0xff091125),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // weekendrelaxRef (0:728)
                                                            'Weekend Relax\n',
                                                            style: SafeGoogleFont(
                                                              'Nunito',
                                                              fontSize: 15 *
                                                                  ffem,
                                                              fontWeight: FontWeight
                                                                  .w700,
                                                              height: 1.2666666667 *
                                                                  ffem / fem,
                                                              letterSpacing: -0.0450000018 *
                                                                  fem,
                                                              color: Color(
                                                                  0xff091125),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // frame2646w7D (0:730)
                                              margin: EdgeInsets.fromLTRB(
                                                  9 * fem, 0 * fem, 58 * fem,
                                                  0 * fem),
                                              width: double.infinity,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment
                                                    .start,
                                                mainAxisSize: MainAxisSize.max,
                                                crossAxisAlignment: CrossAxisAlignment
                                                    .center,
                                                verticalDirection: VerticalDirection
                                                    .down,
                                                children: [
                                                  Container(
                                                    // maskgroupenK (0:731)
                                                   /* margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 0 * fem,
                                                        6 * fem, 0 * fem),*/
                                                    margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 0 * fem, 2 * fem,
                                                        0 * fem),
                                                    width: 24 * fem,
                                                    height: 24 * fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/mask-group-GLf.png',
                                                      width: 24 * fem,
                                                      height: 24 * fem,
                                                    ),
                                                  ),
                                                  Container(
                                                    // hamburgerdibovinoAkf (0:734)
                                                    margin: EdgeInsets.fromLTRB(
                                                        0 * fem, 1 * fem,
                                                        0 * fem, 0 * fem),
                                                    child: Text(
                                                      'TantoSvago',
                                                      style: SafeGoogleFont(
                                                        'Nunito',
                                                        fontSize: 12 * ffem,
                                                        fontWeight: FontWeight
                                                            .w400,
                                                        height: 1.3625 * ffem /
                                                            fem,
                                                        color: Color(
                                                            0xff8a94a6),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // goditiogniattimoTzf (0:736)
                              left: 20 * fem,
                              top: 991 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 148 * fem,
                                  height: 25 * fem,
                                  child: Text(
                                    'Goditi ogni attimo',
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 18 * ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xff22408b),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group2373wew (0:737)
                              left: 20 * fem,
                              top: 22 * fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(
                                    13.36 * fem, 8 * fem, 8 * fem, 8 * fem),
                                width: 336 * fem,
                                height: 72 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff426bd1)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(8 * fem),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // giftpresentcouponcertificatevo (I0:737;3409:44617)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 13.84 * fem,
                                          16.54 * fem),
                                      width: 20.8 * fem,
                                      height: 14.26 * fem,
                                      child: Image.asset(
                                        'assets/page-1/images/giftpresentcouponcertificatevoucher.png',
                                        width: 20.8 * fem,
                                        height: 14.26 * fem,
                                      ),
                                    ),
                                    Container(
                                      // group2475VK5 (I0:737;3024:38834)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 9 * fem, 12 * fem, 9 * fem),
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .start,
                                        children: [
                                          Container(
                                            // budgetdisponibileQwq (I0:737;3024:38836)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 0 * fem,
                                                4 * fem),
                                            child: Text(
                                              'Budget disponibile',
                                              style: SafeGoogleFont(
                                                'Nunito',
                                                fontSize: 14 * ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.1428571429 * ffem /
                                                    fem,
                                                letterSpacing: 0.200000003 *
                                                    fem,
                                                color: Color(0xff1b1b1b),
                                              ),
                                            ),
                                          ),
                                          RichText(

                                            textScaleFactor: 1.0,
                                            textDirection: null,
                                            textAlign: TextAlign.start,
                                            // subtitleXFm (I0:737;3024:38837)
                                            text: TextSpan(
                                              style: SafeGoogleFont(
                                                'Sora',
                                                fontSize: 12 * ffem,
                                                fontWeight: FontWeight.w300,
                                                height: 1.5 * ffem / fem,
                                                letterSpacing: -0.1199999973 *
                                                    fem,
                                                color: Color(0xffa7aebe),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'Prima scadenza ',
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 12 * ffem,
                                                    fontWeight: FontWeight.w300,
                                                    height: 1.5 * ffem / fem,
                                                    letterSpacing: -0.1199999973 *
                                                        fem,
                                                    color: Color(0xffa7aebe),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: ' 12/2022',
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 12 * ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.5 * ffem / fem,
                                                    letterSpacing: -0.1199999973 *
                                                        fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogroupcr1m82b (FKEW3NcZdNVqbHYVV5cr1m)
                                      width: 133 * fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        color: Color(0xffe6ecf9),
                                        borderRadius: BorderRadius.circular(
                                            8 * fem),
                                      ),
                                      child: Center(
                                        child: Center(
                                          child: Text(
                                            '570.00€',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont(
                                              'Nunito',
                                              fontSize: 24 * ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 0.6666666667 * ffem / fem,
                                              letterSpacing: 1 * fem,
                                              color: Color(0xff2b50b0),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // homepartnersallNxX (I0:738;3024:39041)
                              left: 20 * fem,
                              top: 295 * fem,
                              child: Container(
                                width: 418.5 * fem,
                                height: 140 * fem,
                                child: Container(
                                  // autogroupb8ebVnF (FKEWEhd2DnAgHS6s35b8EB)
                                  width: 331 * fem,
                                  height: 25 * fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // giftcardinevidenzaEjq (I0:738;3024:39043)
                                        constraints: null,
                                        padding: null,
                                        clipBehavior: Clip.none,
                                        margin: EdgeInsets.fromLTRB(
                                            0 * fem, 0 * fem, 37.4 * fem,
                                            0 * fem),
                                        child: Text(
                                          'Buoni acquisto in evidenza\n',
                                          style: SafeGoogleFont(
                                            'Nunito',
                                            fontSize: 18 * ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.3625 * ffem / fem,
                                            color: Color(0xff22408b),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // veditutte967 (I0:738;3024:38994)
                                        'Vedi tutte',
                                        textAlign: TextAlign.right,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 13 * ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.6923076923 * ffem / fem,
                                          decoration: TextDecoration.underline,
                                          color: Color(0xff2b50b0),
                                          decorationColor: Color(0xff2b50b0),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // component4g63 (0:739)
                              left: 9 * fem,
                              top: 335 * fem,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 7.97 * fem, 0 * fem),
                                width: 558.97 * fem,
                                height: 93 * fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // amazongiftcardimgaSK (0:741)
                                      width: 140 * fem,
                                      height: 93 * fem,
                                      child: Image.asset(
                                        'assets/page-1/images/amazon-gift-card-img-g55.png',
                                        width: 140 * fem,
                                        height: 93 * fem,
                                      ),
                                    ),
                                    Container(
                                      // autogroupn99hW55 (FKEWY2TVFE8fhJij4Fn99H)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 6.5 * fem, 0 * fem),
                                      padding: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 6.97 * fem,
                                          0 * fem),
                                      width: 278.5 * fem,
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .center,
                                        children: [
                                          Container(
                                            // amazongiftcardimgPef (0:757)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 6.01 * fem,
                                                0 * fem),
                                            width: 139.5 * fem,
                                            height: 93 * fem,
                                            child: Image.asset(
                                              'assets/page-1/images/amazon-gift-card-img.png',
                                              width: 139.5 * fem,
                                              height: 93 * fem,
                                            ),
                                          ),
                                          Container(
                                            // welfarecardmysarmazallando6JB (0:767)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 6.05 * fem, 0 * fem,
                                                6.51 * fem),
                                            padding: EdgeInsets.fromLTRB(
                                                20.92 * fem, 24.18 * fem,
                                                20.12 * fem, 19.83 * fem),
                                            width: 126.02 * fem,
                                            height: double.infinity,
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Color(0xffd2dcf4)),
                                              color: Color(0xff000000),
                                              borderRadius: BorderRadius
                                                  .circular(
                                                  11.1600008011 * fem),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x21000000),
                                                  offset: Offset(
                                                      0 * fem, 0 * fem),
                                                  blurRadius: 8 * fem,
                                                ),
                                              ],
                                            ),
                                            child: Column(

                                              /*mainAxisAlignment: MainAxisAlignment
                                                  .start,
                                              mainAxisSize: MainAxisSize.max,
                                              crossAxisAlignment: CrossAxisAlignment
                                                  .center,
                                              textDirection: null,
                                              verticalDirection: VerticalDirection
                                                  .down,*/
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min, // Cambiato da max a min
                                              textDirection: TextDirection.ltr, // Sostituito con TextDirection.ltr
                                              verticalDirection: VerticalDirection.down,
                                              children: [
                                                Container(
                                                  // gamestop1v2K (0:769)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      11.16 * fem),
                                                      width: 84.97 * fem,
                                                  height: 16.28 * fem,

                                                  child: Image.asset(
                                                    'assets/page-1/images/gamestop-1.png',
                                                    width: 84.97 * fem,
                                                    height: 16.28 * fem,
                                                  ),
                                                ),
                                             Expanded(
                                                flex: 1,
                                                child: Container(
                                                  // giftcard1pT (0:775)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0.72 * fem, 0 * fem,
                                                      0 * fem, 0 * fem),
                                                  child: Text(
                                                    'GIFT CARD',
                                                    style: SafeGoogleFont(
                                                      'IBM Plex Sans',
                                                      fontSize: 6.738263607 *
                                                          ffem,
                                                      fontWeight: FontWeight
                                                          .w400,
                                                      height: 1.3 * ffem / fem,
                                                      letterSpacing: 2.3250000477 *
                                                          fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                             ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // pexelssulimansallehi212816527s (0:778)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 1 * fem),
                                      width: 126 * fem,
                                      height: 80 * fem,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            11.1599998474 * fem),
                                        border: Border.all(
                                            color: Color(0xffd2dcf4)),
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-iHu.png',
                                          ),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x0c000000),
                                            offset: Offset(0 * fem, 0 * fem),
                                            blurRadius: 9.5 * fem,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupkyx7MG3 (FKEWqrH7yRnkff1YchKYx7)
                        margin: EdgeInsets.fromLTRB(
                            9 * fem, 0 * fem, 0 * fem, 0 * fem),
                        width: 617 * fem,
                        height: 252 * fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // rectangle4445ryV (0:658)
                              left: 0 * fem,
                              top: 0 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 359 * fem,
                                  height: 232 * fem,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          12 * fem),
                                      color: Color(0xff8e88d5),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // danonperdereMfM (0:735)
                              left: 15 * fem,
                              top: 12 * fem,
                              child: Align(
                                child: SizedBox(
                                  width: 128 * fem,
                                  height: 25 * fem,
                                  child: Text(
                                    'Da non perdere',
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 18 * ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // component6qqR (0:780)
                              left: 12 * fem,
                              top: 58 * fem,
                              child: Container(
                                width: 605 * fem,
                                height: 194 * fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame5066mDH (0:781)
                                      padding: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 8 * fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(
                                            12 * fem),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x21000000),
                                            offset: Offset(0 * fem, 0 * fem),
                                            blurRadius: 8 * fem,
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .start,
                                        children: [
                                          Container(
                                            // cardrEj (0:782)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 0 * fem,
                                                6 * fem),
                                            width: 140 * fem,
                                            height: 100 * fem,
                                            child: Image.asset(
                                              'assets/page-1/images/card.png',
                                              width: 140 * fem,
                                              height: 100 * fem,
                                            ),
                                          ),
                                          Container(
                                            // frame50579jd (0:785)
                                            margin: EdgeInsets.fromLTRB(
                                                11 * fem, 0 * fem, 0 * fem,
                                                0 * fem),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Container(
                                                  // roma5tB (0:786)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      1 * fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 10 * ffem,
                                                      fontWeight: FontWeight
                                                          .w500,
                                                      height: 2 * ffem / fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // visitamedicagenericaopB (0:787)
                                                  constraints: BoxConstraints(
                                                    maxWidth: 87 * fem,
                                                  ),
                                                  child: Text(
                                                    'Visita medica generica',
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 14 * ffem,
                                                      fontWeight: FontWeight
                                                          .w700,
                                                      height: 1.3625 * ffem /
                                                          fem,
                                                      letterSpacing: -0.0420000017 *
                                                          fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // nomefornitoreiRM (0:788)
                                                  'Nome fornitore',
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 12 * ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.6666666667 *
                                                        ffem / fem,
                                                    color: Color(0xffa7aebe),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 15 * fem,
                                    ),
                                    Container(
                                      // autogrouppdyz3Td (FKEX2We2JAY8cW1JnLpdyZ)
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .center,
                                        children: [
                                          Container(
                                            // frame5067oBu (0:789)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 15 * fem,
                                                0 * fem),
                                            padding: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 0 * fem,
                                                8 * fem),
                                            height: double.infinity,
                                            decoration: BoxDecoration(
                                              color: Color(0xffffffff),
                                              borderRadius: BorderRadius
                                                  .circular(12 * fem),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x21000000),
                                                  offset: Offset(
                                                      0 * fem, 0 * fem),
                                                  blurRadius: 8 * fem,
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Container(
                                                  // cardshZ (0:790)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      6 * fem),
                                                  width: 140 * fem,
                                                  height: 100 * fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/card-6n3.png',
                                                    width: 140 * fem,
                                                    height: 100 * fem,
                                                  ),
                                                ),
                                                Container(
                                                  // frame5057PR1 (0:793)
                                                  margin: EdgeInsets.fromLTRB(
                                                      11 * fem, 0 * fem,
                                                      0 * fem, 0 * fem),
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Container(
                                                        // romaKZZ (0:794)
                                                        margin: EdgeInsets
                                                            .fromLTRB(0 * fem,
                                                            0 * fem, 0 * fem,
                                                            1 * fem),
                                                        child: Text(
                                                          'Roma',
                                                          style: SafeGoogleFont(
                                                            'Nunito',
                                                            fontSize: 10 * ffem,
                                                            fontWeight: FontWeight
                                                                .w500,
                                                            height: 2 * ffem /
                                                                fem,
                                                            color: Color(
                                                                0xff091125),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // analisidelsangue3VZ (0:795)
                                                        constraints: BoxConstraints(
                                                          maxWidth: 69 * fem,
                                                        ),
                                                        child: Text(
                                                          'Analisi del sangue',
                                                          style: SafeGoogleFont(
                                                            'Nunito',
                                                            fontSize: 14 * ffem,
                                                            fontWeight: FontWeight
                                                                .w700,
                                                            height: 1.3625 *
                                                                ffem / fem,
                                                            letterSpacing: -0.0420000017 *
                                                                fem,
                                                            color: Color(
                                                                0xff091125),
                                                          ),
                                                        ),
                                                      ),
                                                      Text(
                                                        // nomefornitoreYhD (0:796)
                                                        'Nome fornitore',
                                                        style: SafeGoogleFont(
                                                          'Nunito',
                                                          fontSize: 12 * ffem,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          height: 1.6666666667 *
                                                              ffem / fem,
                                                          color: Color(
                                                              0xffa7aebe),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // frame5068Huh (0:797)
                                            padding: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 0 * fem,
                                                8 * fem),
                                            height: double.infinity,
                                            decoration: BoxDecoration(
                                              color: Color(0xffffffff),
                                              borderRadius: BorderRadius
                                                  .circular(12 * fem),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x21000000),
                                                  offset: Offset(
                                                      0 * fem, 0 * fem),
                                                  blurRadius: 8 * fem,
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Container(
                                                  // cardo7M (0:798)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      6 * fem),
                                                  width: 140 * fem,
                                                  height: 100 * fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/card-xmD.png',
                                                    width: 140 * fem,
                                                    height: 100 * fem,
                                                  ),
                                                ),
                                                Container(
                                                  // frame5057KLb (0:801)
                                                  margin: EdgeInsets.fromLTRB(
                                                      11 * fem, 0 * fem,
                                                      0 * fem, 0 * fem),
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Container(
                                                        // romarrK (0:802)
                                                        margin: EdgeInsets
                                                            .fromLTRB(0 * fem,
                                                            0 * fem, 0 * fem,
                                                            1 * fem),
                                                        child: Text(
                                                          'Roma',
                                                          style: SafeGoogleFont(
                                                            'Nunito',
                                                            fontSize: 10 * ffem,
                                                            fontWeight: FontWeight
                                                                .w500,
                                                            height: 2 * ffem /
                                                                fem,
                                                            color: Color(
                                                                0xff091125),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // visitaspecialisticayvw (0:803)
                                                        constraints: BoxConstraints(
                                                          maxWidth: 79 * fem,
                                                        ),
                                                        child: Text(
                                                          'Visita specialistica',
                                                          style: SafeGoogleFont(
                                                            'Nunito',
                                                            fontSize: 14 * ffem,
                                                            fontWeight: FontWeight
                                                                .w700,
                                                            height: 1.3625 *
                                                                ffem / fem,
                                                            letterSpacing: -0.0420000017 *
                                                                fem,
                                                            color: Color(
                                                                0xff091125),
                                                          ),
                                                        ),
                                                      ),
                                                      Text(
                                                        // nomefornitoreto1 (0:804)
                                                        'Nome fornitore',
                                                        style: SafeGoogleFont(
                                                          'Nunito',
                                                          fontSize: 12 * ffem,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          height: 1.6666666667 *
                                                              ffem / fem,
                                                          color: Color(
                                                              0xffa7aebe),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 15 * fem,
                                    ),
                                    Container(
                                      // frame5069pRm (0:805)
                                      padding: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 8 * fem),
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(
                                            12 * fem),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x21000000),
                                            offset: Offset(0 * fem, 0 * fem),
                                            blurRadius: 8 * fem,
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .start,
                                        children: [
                                          Container(
                                            // cardWZV (0:806)
                                            margin: EdgeInsets.fromLTRB(
                                                0 * fem, 0 * fem, 0 * fem,
                                                6 * fem),
                                            width: 140 * fem,
                                            height: 100 * fem,
                                            child: Image.asset(
                                              'assets/page-1/images/card-HDR.png',
                                              width: 140 * fem,
                                              height: 100 * fem,
                                            ),
                                          ),
                                          Container(
                                            // frame5057RRZ (0:809)
                                            margin: EdgeInsets.fromLTRB(
                                                11 * fem, 0 * fem, 0 * fem,
                                                0 * fem),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Container(
                                                  // romaMKD (0:810)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      1 * fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 10 * ffem,
                                                      fontWeight: FontWeight
                                                          .w500,
                                                      height: 2 * ffem / fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // taccompletaGh5 (0:811)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem, 0 * fem, 0 * fem,
                                                      19 * fem),
                                                  child: Text(
                                                    'Tac completa\n',
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 14 * ffem,
                                                      fontWeight: FontWeight
                                                          .w700,
                                                      height: 1.3625 * ffem /
                                                          fem,
                                                      letterSpacing: -0.0420000017 *
                                                          fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // nomefornitoreaBy (0:812)
                                                  'Nome fornitore',
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 12 * ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.6666666667 *
                                                        ffem / fem,
                                                    color: Color(0xffa7aebe),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // navappwpWbR (0:814)
                left: 956 * fem,
                top: 753 * fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                      20 * fem, 16 * fem, 20 * fem, 32 * fem),
                  width: 376 * fem,
                  height: 90.98 * fem,
                  decoration: BoxDecoration(
                    color: Color(0xffffffff),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x14000000),
                        offset: Offset(0 * fem, -8 * fem),
                        blurRadius: 12 * fem,
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // navbtnJGP (I0:814;3397:40798)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // homedpT (I0:814;3397:40798;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/home-ekf.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homewaF (I0:814;3397:40798;3397:41108)
                              child: Text(
                                'Home',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtnfFM (I0:814;3397:40804)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // cardgiftcardcAb (I0:814;3397:40804;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/cardgiftcard-rLf.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homeKao (I0:814;3397:40804;3397:41108)
                              child: Text(
                                'Buoni acquisto',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(context, Routes.paginaVoucher);
                        },
                        child: Container(
                          // navbtnEhm (I0:814;3397:40809)
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // bookmarkszS3 (I0:814;3397:40809;3397:40778)
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 0 * fem, 5 * fem),
                                width: 24 * fem,
                                height: 23.98 * fem,

                                child: Image.asset(
                                  'assets/page-1/images/bookmarks-jGT.png',
                                  width: 24 * fem,
                                  height: 23.98 * fem,

                                ),
                              ),

                              Center(
                                // homeW9V (I0:814;3397:40809;3397:40779)
                                child: Text(
                                  'Voucher',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont(
                                    'Nunito',
                                    fontSize: 10 * ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625 * ffem / fem,
                                    color: Color(0xff2b50b0),

                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtnciK (I0:814;3397:40819)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // receiptlong4aK (I0:814;3397:40819;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/receiptlong-kKZ.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homemUj (I0:814;3397:40819;3397:41108)
                              child: Text(
                                'Rimborsi',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtn6G7 (I0:814;3397:40814)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // paymentseHd (I0:814;3397:40814;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/payments-RyZ.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homeMC3 (I0:814;3397:40814;3397:41108)
                              child: Text(
                                'Versamenti',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // navappwpfyR (0:815)
                left: 1434 * fem,
                top: 753 * fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                      20 * fem, 16 * fem, 20 * fem, 32 * fem),
                  width: 376 * fem,
                  height: 90.98 * fem,
                  decoration: BoxDecoration(
                    color: Color(0xffffffff),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x14000000),
                        offset: Offset(0 * fem, -8 * fem),
                        blurRadius: 12 * fem,
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // navbtnWUF (I0:815;3397:40798)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // homesJo (I0:815;3397:40798;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/home-Uoy.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homeaj1 (I0:815;3397:40798;3397:41108)
                              child: Text(
                                'Home',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtn6ST (I0:815;3397:40804)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // cardgiftcardF4T (I0:815;3397:40804;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/cardgiftcard-ueo.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // home9vX (I0:815;3397:40804;3397:41108)
                              child: Text(
                                'Buoni acquisto',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtnUhu (I0:815;3397:40809)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // bookmarksEh5 (I0:815;3397:40809;3397:40778)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/bookmarks-kP9.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homewrP (I0:815;3397:40809;3397:40779)
                              child: Text(
                                'Voucher',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xff2b50b0),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtng3H (I0:815;3397:40819)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // receiptlongdUK (I0:815;3397:40819;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/receiptlong-kWs.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homeM9R (I0:815;3397:40819;3397:41108)
                              child: Text(
                                'Rimborsi',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 28.5 * fem,
                      ),
                      Container(
                        // navbtnFe7 (I0:815;3397:40814)
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // paymentsZPu (I0:815;3397:40814;3397:41107)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 5 * fem),
                              width: 24 * fem,
                              height: 23.98 * fem,
                              child: Image.asset(
                                'assets/page-1/images/payments-D2F.png',
                                width: 24 * fem,
                                height: 23.98 * fem,
                              ),
                            ),
                            Center(
                              // homeFnX (I0:815;3397:40814;3397:41108)
                              child: Text(
                                'Versamenti',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 10 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffd2dcf4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // appbarBAP (0:817)
                left: 0 * fem,
                top: 44 * fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                      20 * fem, 12.18 * fem, 23.93 * fem, 12 * fem),
                  width: 376 * fem,
                  height: 48 * fem,
                  decoration: BoxDecoration(
                    color: Color(0xff2b50b0),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x14000000),
                        offset: Offset(0 * fem, 18 * fem),
                        blurRadius: 20 * fem,
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroup3ubrpj9 (FKEc9s6ZNNsAnNf4Wq3UbR)
                        margin: EdgeInsets.fromLTRB(
                            0 * fem, 0.82 * fem, 120.17 * fem, 0 * fem),
                        padding: EdgeInsets.fromLTRB(
                            8 * fem, 0 * fem, 0 * fem, 0 * fem),
                        height: 23 * fem,
                        child: Align(
                          // logomysarmawelfarevnB (I0:817;2830:39514)
                          alignment: Alignment.topRight,
                          child: SizedBox(
                            width: 90 * fem,
                            height: 21.31 * fem,
                            child: Container(
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 1.69 * fem),
                              child: Image.asset(
                                'assets/page-1/images/logomysarmawelfare.png',
                                width: 90 * fem,
                                height: 21.31 * fem,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // loveheartlikefavorite1od (I0:817;3405:75564)
                        margin: EdgeInsets.fromLTRB(
                            0 * fem, 0 * fem, 26.51 * fem, 0.18 * fem),
                        width: 21.65 * fem,
                        height: 18.62 * fem,
                        child: Image.asset(
                          'assets/page-1/images/loveheartlikefavorite.png',
                          width: 21.65 * fem,
                          height: 18.62 * fem,
                        ),
                      ),
                      Container(
                        // iconsbellalarmalertnotificatio (I0:817;3405:95859)
                        margin: EdgeInsets.fromLTRB(
                            0 * fem, 0 * fem, 26.26 * fem, 0.18 * fem),
                        width: 17.33 * fem,
                        height: 23.64 * fem,
                        child: Image.asset(
                          'assets/page-1/images/icons-bellalarmalertnotification.png',
                          width: 17.33 * fem,
                          height: 23.64 * fem,
                        ),
                      ),
                      Container(
                        // avataruserprofileaccountmanERV (I0:817;3405:73055)
                        margin: EdgeInsets.fromLTRB(
                            0 * fem, 0 * fem, 0 * fem, 0.18 * fem),
                        width: 22.14 * fem,
                        height: 22.13 * fem,
                        child: Image.asset(
                          'assets/page-1/images/avataruserprofileaccountman.png',
                          width: 22.14 * fem,
                          height: 22.13 * fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                  alignment: Alignment.bottomCenter,
                  // Allinea il contenuto in basso
                  child: BottomNavigationBar(
                    items: const <BottomNavigationBarItem>[
                      BottomNavigationBarItem(
                        icon: Icon(Icons.home),
                        label: 'Home',
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.card_giftcard),
                        label: 'Buoni acquisto',
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.bookmarks),
                        label: 'Voucher',
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.receipt_long),
                        label: 'Rimborsi',
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.payments),
                        label: 'Versamenti',
                      ),
                    ],
                    currentIndex: _selectedIndex,
                    selectedItemColor: Colors.blue,
                    // Colore dell'elemento selezionato
                    onTap: _onItemTapped,
                  )

              ),
            ],
          ),
        ),
      ),
    );
  }
}
