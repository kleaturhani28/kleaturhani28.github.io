import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-VQs.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';

class PaginaVoucherdPd extends StatefulWidget {
  @override
  _PaginaVoucherdPd createState() => _PaginaVoucherdPd();
}
class _PaginaVoucherdPd extends State<PaginaVoucherdPd> {int _selectedIndex = 0;

void _onItemTapped(int index) {
  if (index == 0) {
    Navigator.push(context,
      MaterialPageRoute(builder: (context) => MobileStartHomeWelfareCard()),
    );
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return SingleChildScrollView(
      //width: double.infinity,
      child: Container(
        // mobilepaginavoucherAVV (0:1027)
        width: double.infinity,
        height: 1374*fem,
        decoration: BoxDecoration (
          color: Color(0xfff5f8ff),
        ),
        child: Stack(
          children: [
            Positioned(
              // cardappfSF (0:1028)
              left: 0*fem,
              top: 71.6415100098*fem,
              child: Container(
                width: 442.94*fem,
                height: 802.36*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // pexelssulimansallehi21281652de (0:1030)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(47.94*fem, 42.36*fem, 47.94*fem, 42.36*fem),
                        width: 438.68*fem,
                        height: 257.08*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfff3f3f3),
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/page-1/images/pexels-suliman-sallehi-2128165-3-bg.png',
                            ),
                          ),
                        ),
                        child: Container(
                          // frame29652RD (0:1063)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 283.79*fem, 153.36*fem),
                          width: 59*fem,
                          height: 19*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffedd5),
                            borderRadius: BorderRadius.circular(13.8699998856*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ATLETICA',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w700,
                                height: 0.8999999364*ffem/fem,
                                color: Color(0xfff97316),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group2447rf9 (0:1033)
                      left: 20*fem,
                      top: 213.3584899902*fem,
                      child: Container(
                        width: 398*fem,
                        height: 589*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(12*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x0c000000),
                              offset: Offset(0*fem, 0*fem),
                              blurRadius: 9.5*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // frame2359Kod (0:1034)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffe8e8e8)),
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(12*fem),
                          ),
                          child: Stack(
                            children: [

                              Positioned(
                                // frame2456Cns (0:1035)
                                left: 24.07421875*fem,
                                top: 24*fem,
                                child: Container(
                                  width: 343*fem,
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame5066XKM (0:1036)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                        width: 252*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              // abbtoannualepalestraSx7 (0:1037)
                                              'Abb.to annuale palestra',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 20*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 0.95*ffem/fem,
                                                color: Color(0xff333232),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 18*fem,
                                            ),
                                            TextButton(
                                              // varianteprezzoxfZ (0:1038)
                                              onPressed: () {},
                                              style: TextButton.styleFrom (
                                                padding: EdgeInsets.zero,
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 1*fem, 8*fem),
                                                width: double.infinity,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xff7491dd)),
                                                  color: Color(0xffe6ecf9),
                                                  borderRadius: BorderRadius.circular(12*fem),
                                                ),
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // checkboxFef (I0:1038;1:5159)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 13*fem,
                                                          height: 13*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/checkbox-3w5.png',
                                                            width: 13*fem,
                                                            height: 13*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // abbonamento12mesi9900wnP (I0:1038;1:5160)
                                                      constraints: BoxConstraints (
                                                        maxWidth: 165*fem,
                                                      ),
                                                      child: Text(
                                                        'Abbonamento 12 mesi\n99,00 €',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1875*ffem/fem,
                                                          color: Color(0xff333232),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 18*fem,
                                            ),
                                            TextButton(
                                              // varianteprezzo8by (0:1039)
                                              onPressed: () {},
                                              style: TextButton.styleFrom (
                                                padding: EdgeInsets.zero,
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 1*fem, 8*fem),
                                                width: double.infinity,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffd2dcf4)),
                                                  borderRadius: BorderRadius.circular(12*fem),
                                                ),
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // checkbox1fm (I0:1039;1:5156)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 13*fem,
                                                          height: 13*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/checkbox-1hh.png',
                                                            width: 13*fem,
                                                            height: 13*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // abbonamento12mesi9900V59 (I0:1039;1:5157)
                                                      constraints: BoxConstraints (
                                                        maxWidth: 165*fem,
                                                      ),
                                                      child: Text(
                                                        'Abbonamento 12 mesi\n99,00 €',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1875*ffem/fem,
                                                          color: Color(0xff333232),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // inputcontrolwithoutlabeldropdo (0:1041)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                        width: double.infinity,
                                        height: 75*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // rectangle16aj (0:1042)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 288*fem,
                                                  height: 41.22*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(4*fem),
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // outlinedainactiveoV9 (0:1043)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 343*fem,
                                                height: 75*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // autogroupqvqb8GX (FKEhy7aHNPtCA16bSwqVQb)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                                                      width: 288*fem,
                                                      height: 37*fem,
                                                      child: Stack(
                                                        children: [
                                                          Positioned(
                                                            // textfieldoutlineF6F (0:1046)
                                                            left: 0*fem,
                                                            top: 0*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 288*fem,
                                                                height: 37*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/text-field-outline.png',
                                                                  width: 288*fem,
                                                                  height: 37*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),

                                                          Positioned(
                                                            // hamburgerdibovino1Uj (0:1052)
                                                            left: 12.92578125*fem,
                                                            top: 10.4423828125*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 119*fem,
                                                                height: 17*fem,
                                                                child: Text(
                                                                  'Seleziona un familiare',
                                                                  style: SafeGoogleFont (
                                                                    'Nunito',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w400,
                                                                    height: 1.3625*ffem/fem,
                                                                    color: Color(0xff8a94a6),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            // dropdownicon5zP (0:1054)
                                                            left: 263.4145507812*fem,
                                                            top: 17.8748931885*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 7.02*fem,
                                                                height: 2.94*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/dropdown-icon-TLK.png',
                                                                  width: 7.02*fem,
                                                                  height: 2.94*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // autogroupb2qxyZy (FKEi5H4gNMQi4Z3jmDB2QX)
                                                      margin: EdgeInsets.fromLTRB(0.07*fem, 0*fem, 0*fem, 0*fem),
                                                      width: double.infinity,
                                                      height: 29.44*fem,
                                                      child: Text(
                                                        'Da compilare se vuoi assegnare il voucher a un tuo famigliare.',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.4*ffem/fem,
                                                          color: Color(0xffa7aebe),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame5062GZ5 (0:1055)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 142*fem, 0*fem),
                                        width: double.infinity,
                                        height: 24*fem,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame2654zjy (0:1056)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                              width: 147*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                border: Border.all(color: Color(0xffe5e7eb)),
                                              ),
                                              child: Container(
                                                // frame26468bH (0:1057)
                                                width: 132*fem,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // maskgroupsYs (0:1058)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                                      width: 24*fem,
                                                      height: 24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/mask-group-qRy.png',
                                                        width: 24*fem,
                                                        height: 24*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // hamburgerdibovinobDy (0:1061)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                                      child: Text(
                                                        'Palestra sotto casa',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.3625*ffem/fem,
                                                          color: Color(0xff8a94a6),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // padovaWbq (0:1062)
                                              'Padova',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.75*ffem/fem,
                                                letterSpacing: 0.06*fem,
                                                color: Color(0xff1d1e25),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                // dettaglliodescrizioneclose35y (0:1065)
                                left: 0*fem,
                                top: 361*fem,
                                child: Container(
                                  width: 337*fem,
                                  height: 171*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // descrizionewx3 (I0:1065;122:9660)
                                        margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 16*fem),
                                        child: Text(
                                          'Descrizione',
                                          style: SafeGoogleFont (
                                            'Nunito',
                                            fontSize: 18*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.3625*ffem/fem,
                                            color: Color(0xff22408b),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group2451fNF (I0:1065;122:9657)
                                        padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 23*fem, 16*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0xffe8e8e8)),
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x0c000000),
                                              offset: Offset(0*fem, 0*fem),
                                              blurRadius: 9.5*fem,
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Container(
                                              // checosboscologiftilmodopisempl (I0:1065;122:9659)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                                              constraints: BoxConstraints (
                                                maxWidth: 294*fem,
                                              ),
                                              child: Text(
                                                'Che cosè Boscolo Gift? É il modo più semplice e sicuro di regalare (o acquistare) un viaggio o un’esp...',
                                                style: SafeGoogleFont (
                                                  'Nunito',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.07*fem,
                                                  color: Color(0xff283b6c),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // leggidipiBzo (I0:1065;122:9665)
                                              'LEGGI DI PIÙ',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.75*ffem/fem,
                                                letterSpacing: 0.06*fem,
                                                color: Color(0xff2b50b0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group5069XHy (0:1066)
              left: 20*fem,
              top: 839*fem,
              child: Container(
                width: 337*fem,
                height: 408*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // fornitoreTSX (0:1073)
                      margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 16*fem),
                      child: Text(
                        'Fornitore',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff22408b),
                        ),
                      ),
                    ),
                    Container(
                      // group2451x1u (0:1067)
                      width: double.infinity,
                      height: 367*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffe8e8e8)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(8*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x0c000000),
                            offset: Offset(0*fem, 0*fem),
                            blurRadius: 9.5*fem,
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // palestrasottocasaQeb (0:1069)
                            left: 17*fem,
                            top: 116.5*fem,
                            child: Align(
                              child: SizedBox(
                                width: 143*fem,
                                height: 21*fem,
                                child: Text(
                                  'Palestra sotto casa',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3125*ffem/fem,
                                    letterSpacing: 0.08*fem,
                                    color: Color(0xff283b6c),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // padovaviauruguay43351275Ew (0:1070)
                            left: 17*fem,
                            top: 261*fem,
                            child: Align(
                              child: SizedBox(
                                width: 209*fem,
                                height: 21*fem,
                                child: Text(
                                  'Padova, Via Uruguay 43 - 35127',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff1d1e25),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // telefono3904976205109kb (0:1071)
                            left: 17*fem,
                            top: 293*fem,
                            child: Align(
                              child: SizedBox(
                                width: 180*fem,
                                height: 21*fem,
                                child: Text(
                                  'Telefono: +39 049 7620510',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // emailcorporatetravelboscolocom (0:1072)
                            left: 17*fem,
                            top: 322*fem,
                            child: Align(
                              child: SizedBox(
                                width: 231*fem,
                                height: 21*fem,
                                child: Text(
                                  'Email: corporatetravel@boscolo.com',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // image11KHh (0:1074)
                            left: 11*fem,
                            top: 16*fem,
                            child: Align(
                              child: SizedBox(
                                width: 91*fem,
                                height: 83*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-11-f4K.png',
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // autogroupxaqfq19 (FKEiVw2GNBWmgkrK2GXAQF)
                            left: 17*fem,
                            top: 139*fem,

                            child: Container(
                              width: 300*fem,
                              height: 74*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group506291q (0:1075)
                                     width: 70*fem,
                                     height: 74*fem,

                                    child: Image.asset(
                                      'assets/page-1/images/group-5062.png',
                                       width: 70*fem,
                                       height: 74*fem,

                                    ),
                                  ),
                                  SizedBox(
                                    width: 45*fem,
                                  ),
                                  Container(
                                    // group5063fF5 (0:1078)
                                    width: 70*fem,
                                    height: 74*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/group-5063.png',
                                      width: 70*fem,
                                      height: 74*fem,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 45*fem,
                                  ),
                                  Container(
                                    // group5064asq (0:1081)
                                    width: 70*fem,
                                    height: 74*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/group-5064.png',
                                      width: 70*fem,
                                      height: 74*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          Positioned(
          bottom: 70, // Altezza dal basso della pagina
          left: 0,
          right: 0,
          child: GestureDetector(
          onTap: () {
            // Qui inserisco il codice per aprire l'altra pagina
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => PaginaVoucherVQs()),
            );
          },
            child: Center(
              // group5068ttX (0:1084)
              //left: 86*fem,
               //top: 800*fem,

              child: Container(
                width: 205*fem,
                height: 48*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2b50b0),
                  borderRadius: BorderRadius.circular(500*fem),
                ),
                child: Center(
                  child: Text(
                    'Acquista',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ),
           ),
            Positioned(
              // appbarx7h (0:1088)
              left: 0*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 377*fem,
                  height: 48*fem,
                  child: Image.asset(
                    'assets/page-1/images/appbar-dV9.png',
                    width: 377*fem,
                    height: 48*fem,
                  ),
                ),
              ),
            ),

            Container(
                alignment: Alignment.bottomCenter,
                // Allinea il contenuto in basso
                child: BottomNavigationBar(
                  items: const <BottomNavigationBarItem>[
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.card_giftcard),
                      label: 'Buoni acquisto',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.bookmarks),
                      label: 'Voucher',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.receipt_long),
                      label: 'Rimborsi',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.payments),
                      label: 'Versamenti',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: Colors.blue,
                  // Colore dell'elemento selezionato
                  onTap: _onItemTapped,
                )

            ),
          ],
        ),
      ),
          );
  }
}