import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';
import 'package:myapp/routes.dart';
import 'package:myapp/page-1/mobile-pagina-categoria-voucher.dart';

class PaginaVoucher extends StatefulWidget {
  @override
  _PaginaVoucherState createState() => _PaginaVoucherState();
}
class _PaginaVoucherState extends State<PaginaVoucher> {int _selectedIndex = 0;

void _onItemTapped(int index) {
  if (index == 2) {
    Navigator.push(context,
      MaterialPageRoute(builder: (context) => PaginaVoucher()),
    );
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Scaffold(
      body:SingleChildScrollView(
    child: Container(
      width: double.infinity,
      child: Container(
        // mobilepaginavoucherjkK (0:819)
        padding: EdgeInsets.fromLTRB(0*fem, 44*fem, 0*fem, 0.02*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff5f8ff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // appbarMmh (0:834)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: 377*fem,
              height: 48*fem,
              child: Image.asset(
                'assets/page-1/images/appbar-PvF.png',
                width: 377*fem,
                height: 48*fem,
              ),
            ),
            Container(
              // voucherrCf (0:820)
              margin: EdgeInsets.fromLTRB(22*fem, 0*fem, 0*fem, 24*fem),
              child: Text(
                'Voucher',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff22408b),
                ),
              ),
            ),
            Container(
              // frame5057ikf (0:821)
              margin: EdgeInsets.fromLTRB(22*fem, 0*fem, 28*fem, 37*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  TextButton(
                    // filter1Ruy (0:822)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-8Ph.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Svago e tempo libero',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff426bd1),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1T5y (0:823)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-caB.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Esperienze',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff716aca),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1hFD (0:824)
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => PaginaCategoriaVoucher()),
                      );
                    },
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-sk3.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Palestre e centri sportivi',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xfff97316),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1M4s (0:825)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-SJj.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Viaggi e vacanze',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff0d9488),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1nfy (0:826)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-Y9m.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Corsi',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffec4899),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1oLB (0:827)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-N2T.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Visite specialistiche ed esami diagnostici',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff0891b2),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1s59 (0:828)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-xx7.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Cure odontoiatriche',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff84cc16),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1Wto (0:829)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Ottici',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xfff45358),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1AyM (0:830)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-7XD.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Benessere',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff596fa6),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1Qsh (0:831)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-5jd.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Assistenza e previdenza sanitaria',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xfff59e0b),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18*fem,
                  ),
                  TextButton(
                    // filter1g4X (0:832)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 74*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/mask-group-W63.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Zainetto sanitario',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff426bd1),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
              Container(
              alignment: Alignment.bottomCenter,
    // Allinea il contenuto in basso
    child: BottomNavigationBar(
    items: const <BottomNavigationBarItem>[
    BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.card_giftcard),
    label: 'Buoni acquisto',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.bookmarks),
    label: 'Voucher',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.receipt_long),
    label: 'Rimborsi',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.payments),
    label: 'Versamenti',
    ),
    ],
    currentIndex: _selectedIndex,
    //selectedItemColor: Colors.blue,
    // Colore dell'elemento selezionato
    onTap: _onItemTapped,
    )

    ),
    ],
    ),
    ),
    ),
      ),
    );
  }
}