import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-dPd.dart';

class PaginaVoucherB11 extends StatefulWidget {
  @override
  _PaginaVoucherB11 createState() => _PaginaVoucherB11();
}
class _PaginaVoucherB11 extends State<PaginaVoucherB11> {int _selectedIndex = 0;

void _onItemTapped(int index) {
  if (index == 0) {
    Navigator.push(context,
      MaterialPageRoute(builder: (context) => MobileStartHomeWelfareCard()),
    );
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return SingleChildScrollView(

      child: Container(
        // mobilepaginavoucher64o (0:964)
        width: double.infinity,
        height: 1374*fem,
        decoration: BoxDecoration (
          color: Color(0xfff5f8ff),
        ),
        child: Stack(
          children: [
            Positioned(
              // cardappyPV (0:965)
              left: 0*fem,
              top: 70.6415100098*fem,
              child: Container(
                width: 442.94*fem,
                height: 803.36*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // pexelssulimansallehi21281652de (0:967)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(47.94*fem, 43.36*fem, 47.94*fem, 43.36*fem),
                        width: 438.68*fem,
                        height: 257.08*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfff3f3f3),
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/page-1/images/pexels-suliman-sallehi-2128165-3-bg-Ea3.png',
                            ),
                          ),
                        ),
                        child: Container(
                          // frame29656cX (0:1000)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 283.79*fem, 151.36*fem),
                          width: 59*fem,
                          height: 19*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffedd5),
                            borderRadius: BorderRadius.circular(13.8699998856*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ATLETICA',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w700,
                                height: 0.8999999364*ffem/fem,
                                color: Color(0xfff97316),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group2447iP1 (0:970)
                      left: 20*fem,
                      top: 214.3584899902*fem,
                      child: Container(
                        width: 398*fem,
                        height: 589*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(12*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x0c000000),
                              offset: Offset(0*fem, 0*fem),
                              blurRadius: 9.5*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // frame2359yZq (0:971)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffe8e8e8)),
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(12*fem),
                          ),
                          child: Stack(
                            children: [

                              Positioned(
                                // frame2456P9h (0:972)
                                left: 24.07421875*fem,
                                top: 24*fem,
                                child: Container(
                                  width: 343*fem,
                                  //height: 292*fem,
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),

                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame5066J1m (0:973)
                                        //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                        width: 252*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              // abbtoannualepalestracYF (0:974)
                                              'Abb.to annuale palestra',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                //fontSize: 20*ffem,
                                                fontSize: 18.6*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 0.95*ffem/fem,
                                                color: Color(0xff333232),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 18*fem,
                                            ),
                                            TextButton(
                                              // varianteprezzoWdd (0:975)
                                              onPressed: () {

                                                },
                                              style: TextButton.styleFrom (
                                                padding: EdgeInsets.zero,
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 1*fem, 8*fem),
                                                width: double.infinity,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffd2dcf4)),
                                                  borderRadius: BorderRadius.circular(12*fem),
                                                ),
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // checkboxb9H (I0:975;1:5156)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(builder: (context) => PaginaVoucherdPd()),
                                                          );
                                                        },
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 13*fem,
                                                          height: 13*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/checkbox.png',
                                                            width: 13*fem,
                                                            height: 13*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),

                                                     Container(
                                                      // abbonamento12mesi9900GWK (I0:975;1:5157)
                                                      constraints: BoxConstraints (
                                                        maxWidth: 165*fem,
                                                      ),
                                                      child: Text(
                                                        'Abbonamento 12 mesi\n99,00 €',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1875*ffem/fem,
                                                          color: Color(0xff333232),
                                                        ),
                                                      ),
                                                    ),

                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 18*fem,
                                            ),
                                            TextButton(
                                              // varianteprezzo9a7 (0:976)
                                              onPressed: () {},
                                              style: TextButton.styleFrom (
                                                padding: EdgeInsets.zero,
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 1*fem, 8*fem),
                                                width: double.infinity,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffd2dcf4)),
                                                  borderRadius: BorderRadius.circular(12*fem),
                                                ),
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // checkboxTKu (I0:976;1:5156)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Container(
                                                          width: 13*fem,
                                                          height: 13*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/checkbox-Pno.png',
                                                            width: 13*fem,
                                                            height: 13*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // abbonamento12mesi9900YMM (I0:976;1:5157)
                                                      constraints: BoxConstraints (
                                                        maxWidth: 165*fem,
                                                      ),
                                                      child: Text(
                                                        'Abbonamento 12 mesi\n99,00 €',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 16*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.1875*ffem/fem,
                                                          color: Color(0xff333232),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // inputcontrolwithoutlabeldropdo (0:978)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                        width: double.infinity,
                                        height: 75*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // rectangle1Z1Z (0:979)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 288*fem,
                                                  height: 41.22*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(4*fem),
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // outlinedainactive3xK (0:980)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 343*fem,
                                                height: 75*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // autogroup5wybAGF (FKEfwWHagTCJP4Muvf5wYB)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                                                      width: 288*fem,
                                                      height: 37*fem,
                                                      child: Stack(
                                                        children: [
                                                          Positioned(
                                                            // textfieldoutlineSzT (0:983)
                                                            left: 0*fem,
                                                            top: 0*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 288*fem,
                                                                height: 37*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/text-field-outline-7HH.png',
                                                                  width: 288*fem,
                                                                  height: 37*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),

                                                          Positioned(
                                                            // hamburgerdibovinoPoD (0:989)
                                                            left: 12.92578125*fem,
                                                            top: 10.4423828125*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 119*fem,
                                                                height: 17*fem,
                                                                child: Text(
                                                                  'Seleziona un familiare',
                                                                  style: SafeGoogleFont (
                                                                    'Nunito',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w400,
                                                                    height: 1.3625*ffem/fem,
                                                                    color: Color(0xff8a94a6),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            // dropdowniconG6K (0:991)
                                                            left: 263.4145507812*fem,
                                                            top: 17.8748931885*fem,
                                                            child: Align(
                                                              child: SizedBox(
                                                                width: 7.02*fem,
                                                                height: 2.94*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/dropdown-icon.png',
                                                                  width: 7.02*fem,
                                                                  height: 2.94*fem,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      // autogrouplgatyWX (FKEg4FbLfd2bSVvqhjLGaT)
                                                      margin: EdgeInsets.fromLTRB(0.07*fem, 0*fem, 0*fem, 0*fem),
                                                      width: double.infinity,
                                                      height: 29.44*fem,
                                                      child: Text(
                                                        'Da compilare se vuoi assegnare il voucher a un tuo famigliare.',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 10*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.4*ffem/fem,
                                                          color: Color(0xffa7aebe),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame5062UCP (0:992)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 142*fem, 0*fem),
                                        width: double.infinity,
                                        height: 24*fem,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame2654C8P (0:993)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                              width: 147*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                border: Border.all(color: Color(0xffe5e7eb)),
                                              ),
                                              child: Container(
                                                // frame2646Kyh (0:994)
                                                width: 132*fem,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // maskgroupt1D (0:995)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                                      width: 24*fem,
                                                      height: 24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/mask-group-6Du.png',
                                                        width: 24*fem,
                                                        height: 24*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // hamburgerdibovinooP5 (0:998)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                                      child: Text(
                                                        'Palestra sotto casa',
                                                        style: SafeGoogleFont (
                                                          'Nunito',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.3625*ffem/fem,
                                                          color: Color(0xff8a94a6),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // padova7ef (0:999)
                                              'Padova',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.75*ffem/fem,
                                                letterSpacing: 0.06*fem,
                                                color: Color(0xff1d1e25),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                // dettaglliodescrizionecloseEjH (0:1002)
                                left: 0*fem,
                                top: 361*fem,
                                child: Container(
                                  width: 337*fem,
                                  height: 171*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // descrizionejvw (I0:1002;122:9660)
                                        margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 16*fem),
                                        child: Text(
                                          'Descrizione',
                                          style: SafeGoogleFont (
                                            'Nunito',
                                            fontSize: 18*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.3625*ffem/fem,
                                            color: Color(0xff22408b),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group24514CX (I0:1002;122:9657)
                                        padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 23*fem, 16*fem),
                                        width: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0xffe8e8e8)),
                                          color: Color(0xffffffff),
                                          borderRadius: BorderRadius.circular(8*fem),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x0c000000),
                                              offset: Offset(0*fem, 0*fem),
                                              blurRadius: 9.5*fem,
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Container(
                                              // checosboscologiftilmodopisempl (I0:1002;122:9659)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                                              constraints: BoxConstraints (
                                                maxWidth: 294*fem,
                                              ),
                                              child: Text(
                                                'Che cosè Boscolo Gift? É il modo più semplice e sicuro di regalare (o acquistare) un viaggio o un’esp...',
                                                style: SafeGoogleFont (
                                                  'Nunito',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.07*fem,
                                                  color: Color(0xff283b6c),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // leggidipiMaw (I0:1002;122:9665)
                                              'LEGGI DI PIÙ',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.75*ffem/fem,
                                                letterSpacing: 0.06*fem,
                                                color: Color(0xff2b50b0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),

                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group5065UvT (0:1003)
              left: 20*fem,
              top: 839*fem,
              child: Container(
                width: 337*fem,
                height: 408*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // fornitoreCbZ (0:1010)
                      margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 16*fem),
                      child: Text(
                        'Fornitore',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff22408b),
                        ),
                      ),
                    ),
                    Container(
                      // group2451v1m (0:1004)
                      width: double.infinity,
                      height: 367*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffe8e8e8)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(8*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x0c000000),
                            offset: Offset(0*fem, 0*fem),
                            blurRadius: 9.5*fem,
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // palestrasottocasaQhd (0:1006)
                            left: 17*fem,
                            top: 116.5*fem,
                            child: Align(
                              child: SizedBox(
                                width: 143*fem,
                                height: 21*fem,
                                child: Text(
                                  'Palestra sotto casa',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3125*ffem/fem,
                                    letterSpacing: 0.08*fem,
                                    color: Color(0xff283b6c),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // padovaviauruguay43351274nB (0:1007)
                            left: 17*fem,
                            top: 261*fem,
                            child: Align(
                              child: SizedBox(
                                width: 209*fem,
                                height: 21*fem,
                                child: Text(
                                  'Padova, Via Uruguay 43 - 35127',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff1d1e25),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // telefono390497620510Xvf (0:1008)
                            left: 17*fem,
                            top: 293*fem,
                            child: Align(
                              child: SizedBox(
                                width: 180*fem,
                                height: 21*fem,
                                child: Text(
                                  'Telefono: +39 049 7620510',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // emailcorporatetravelboscolocom (0:1009)
                            left: 17*fem,
                            top: 322*fem,
                            child: Align(
                              child: SizedBox(
                                width: 231*fem,
                                height: 21*fem,
                                child: Text(
                                  'Email: corporatetravel@boscolo.com',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.07*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // image11H2f (0:1011)
                            left: 11*fem,
                            top: 16*fem,
                            child: Align(
                              child: SizedBox(
                                width: 91*fem,
                                height: 83*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-11.png',
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // autogroupuqkhPbV (FKEgVKhu5kD52mTYaWUQKH)
                            left: 17*fem,
                            top: 162*fem,
                            child: Container(
                              width: 300*fem,
                              height: 70*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group5062v5d (0:1012)
                                    //padding: EdgeInsets.fromLTRB(19*fem, 19*fem, 19*fem, 19*fem),
                                    padding: EdgeInsets.fromLTRB(19*fem, 19*fem, 6*fem, 19*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xffe8e8e8)),
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      // phoneEc7 (0:1014)
                                      child: SizedBox(
                                        width: 32*fem,
                                        height: 32*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/phone.png',
                                          width: 32*fem,
                                          height: 32*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 45*fem,
                                  ),
                                  Container(
                                    // group5063kaT (0:1015)
                                    padding: EdgeInsets.fromLTRB(19*fem, 19*fem, 19*fem, 19*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xffe8e8e8)),
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      // placeFn7 (0:1017)
                                      child: SizedBox(
                                        width: 32*fem,
                                        height: 32*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/place.png',
                                          width: 32*fem,
                                          height: 32*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 45*fem,
                                  ),
                                  Container(
                                    // group5064aJb (0:1018)
                                    padding: EdgeInsets.fromLTRB(19*fem, 19*fem, 19*fem, 19*fem),
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xffe8e8e8)),
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      // emailhPD (0:1020)
                                      child: SizedBox(
                                        width: 32*fem,
                                        height: 32*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/email.png',
                                          width: 32*fem,
                                          height: 32*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group50682Ab (0:1021)
              left: 86*fem,
              //top: 646*fem,
              top:1250*fem,
              child: Container(
                width: 205*fem,
                height: 48*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2b50b0),
                  borderRadius: BorderRadius.circular(500*fem),
                ),
                child: Center(
                  child: Text(
                    'Acquista',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // appbar58s (0:1025)
              left: 0*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 377*fem,
                  height: 48*fem,
                  child: Image.asset(
                    'assets/page-1/images/appbar.png',
                    width: 377*fem,
                    height: 48*fem,
                  ),
                ),
              ),
            ),

            Container(
                alignment: Alignment.bottomCenter,
                // Allinea il contenuto in basso
                child: BottomNavigationBar(
                  items: const <BottomNavigationBarItem>[
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.card_giftcard),
                      label: 'Buoni acquisto',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.bookmarks),
                      label: 'Voucher',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.receipt_long),
                      label: 'Rimborsi',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.payments),
                      label: 'Versamenti',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: Colors.blue,
                  // Colore dell'elemento selezionato
                  onTap: _onItemTapped,
                )

            ),
          ],
        ),
      ),
          );
  }
}