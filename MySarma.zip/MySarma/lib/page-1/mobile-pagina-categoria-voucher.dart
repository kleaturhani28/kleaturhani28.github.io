import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-B11.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';
import 'package:myapp/routes.dart';

class PaginaCategoriaVoucher extends StatefulWidget {
  @override
  _PaginaCategoriaVoucherState createState() => _PaginaCategoriaVoucherState();
}
class _PaginaCategoriaVoucherState extends State<PaginaCategoriaVoucher> {int _selectedIndex = 0;

void _onItemTapped(int index) {
  if (index == 0) {
    Navigator.push(context,
      MaterialPageRoute(builder: (context) => MobileStartHomeWelfareCard()),
    );
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return SingleChildScrollView(

      child: Container(
        // mobilepaginacategoriavoucherxH (0:836)
        width: double.infinity,
        height: 1025*fem,
        decoration: BoxDecoration (
          color: Color(0xfff5f8ff),
        ),
        child: Stack(
          children: [
            Positioned(
              // frame50703Jo (0:837)
              left: 19*fem,
              top: 237*fem,
              child: Container(
                width: 337*fem,
                height: 671*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group5057LYo (0:838)
                      width: double.infinity,
                      height: 213*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                         Container(
                            // cardvoucherGBZ (0:839)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                          child: Container(
                              // frame2648jaw (0:840)
                              width: 186*fem,
                              height: 205*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // group2647591 (0:841)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    height: 173*fem,

                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // pexelssulimansallehi21281652de (0:843)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(17*fem, 7*fem, 17*fem, 7*fem),
                                            width: 186*fem,
                                            height: 109*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xfff3f3f3),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/pexels-suliman-sallehi-2128165-3-bg-j6X.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              // frame2965eLX (0:846)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 93*fem, 76*fem),
                                              width: 59*fem,
                                              height: 19*fem,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffedd5),
                                                borderRadius: BorderRadius.circular(13.8699998856*fem),
                                              ),
                                              child: Center(
                                                child: Text(
                                                  'ATLETICA',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 0.8999999364*ffem/fem,
                                                    color: Color(0xfff97316),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // frame605Aw (0:848)
                                          left: 11*fem,
                                          top: 107*fem,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 0*fem),
                                            width: 159*fem,
                                            height: 66*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xffffffff),
                                              borderRadius: BorderRadius.only (
                                                bottomRight: Radius.circular(12*fem),
                                                bottomLeft: Radius.circular(12*fem),
                                              ),
                                            ),
                                            child: Container(
                                              // frame119Zbu (0:849)
                                              width: 106*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // romauvf (0:850)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    child: Text(
                                                      'Roma',
                                                      style: SafeGoogleFont (
                                                        'Nunito',
                                                        fontSize: 10*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 2*ffem/fem,
                                                        color: Color(0xff091125),
                                                      ),
                                                    ),
                                                  ),
                                                  GestureDetector(
                                                     onTap: () {
                                                     Navigator.push(
                                                     context,
                                                     MaterialPageRoute(builder: (context) => PaginaVoucherB11()),
                                                     );
                                                   },
                                                  child: Container(

                                                      // abbtoannualepalestrapXq (0:851)
                                                    constraints: BoxConstraints (
                                                      maxWidth: 106*fem,
                                                    ),

                                                    child: Text(
                                                      'Abb.to annuale palestra',
                                                      style: SafeGoogleFont (
                                                        'Nunito',
                                                        fontSize: 15*ffem,
                                                        fontWeight: FontWeight.w700,
                                                        height: 1.2666666667*ffem/fem,
                                                        letterSpacing: -0.0450000018*fem,
                                                        color: Color(0xff091125),
                                                      ),
                                                    ),
                                                  ),
                                            ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646KjV (0:853)
                                    margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 13*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [

                                        Container(
                                          // maskgroupqxj (0:854)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-exX.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinoZdq (0:857)
                                          margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'Palestra sotto casa',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                            Container(
                            // cardvoucherGHM (0:858)
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // frame2648xfy (0:859)
                              width: 159*fem,
                              height: 204*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26476XH (0:860)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // pexelssulimansallehi21281652de (0:862)
                                          padding: EdgeInsets.fromLTRB(6*fem, 6*fem, 6*fem, 6*fem),
                                          width: double.infinity,
                                          height: 106*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xfff3f3f3),
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-jdH.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            // frame2965hGB (0:865)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 75*fem),
                                            width: 51*fem,
                                            height: 19*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xffffedd5),
                                              borderRadius: BorderRadius.circular(13.8699998856*fem),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'DANZA',
                                                style: SafeGoogleFont (
                                                  'Nunito',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 0.8999999364*ffem/fem,
                                                  color: Color(0xfff97316),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame60ZJP (0:867)
                                          padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 4*fem),
                                          width: double.infinity,
                                          height: 66*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                            borderRadius: BorderRadius.only (
                                              bottomRight: Radius.circular(12*fem),
                                              bottomLeft: Radius.circular(12*fem),
                                            ),
                                          ),
                                          child: Container(
                                            // frame119HEP (0:868)
                                            width: 109*fem,
                                            height: 43*fem,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // romacnT (0:869)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont (
                                                      'Nunito',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 2*ffem/fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // weekendrelaxLyM (0:870)
                                                  'Weekend Relax\n',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2666666667*ffem/fem,
                                                    letterSpacing: -0.0450000018*fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646UJs (0:872)
                                    margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 57*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // maskgroup1Zh (0:873)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                        width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-PQj.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinoHXD (0:876)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'TantoSvago',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16*fem,
                    ),
                    Container(
                      // group5058xNT (0:877)
                      width: double.infinity,
                      height: 213*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cardvoucherGtw (0:878)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // frame2648yHZ (0:879)
                              width: 161*fem,
                              height: 205*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group2647K6X (0:880)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // pexelssulimansallehi21281652de (0:882)
                                          padding: EdgeInsets.fromLTRB(1*fem, 1*fem, 1*fem, 0*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xfff3f3f3),
                                          ),
                                          child: Align(
                                            // pexelssulimansallehi21281652As (0:883)
                                            alignment: Alignment.bottomCenter,
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 106*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xfff3f3f3),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-39h.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame605ju (0:885)
                                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 4*fem),
                                          width: double.infinity,
                                          height: 66*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                            borderRadius: BorderRadius.only (
                                              bottomRight: Radius.circular(12*fem),
                                              bottomLeft: Radius.circular(12*fem),
                                            ),
                                          ),
                                          child: Container(
                                            // frame119BY3 (0:886)
                                            width: 109*fem,
                                            height: 43*fem,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // romaXbu (0:887)
                                                  //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont (
                                                      'Nunito',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 2*ffem/fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // weekendrelax3q9 (0:888)
                                                  'Weekend Relax\n',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2666666667*ffem/fem,
                                                    letterSpacing: -0.0450000018*fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646NsR (0:890)
                                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 58*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // maskgroup7a7 (0:891)
                                          //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-c23.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinoEud (0:894)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'TantoSvago',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // cardvoucherk7H (0:895)
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // frame2648TXV (0:896)
                              width: 161*fem,
                              height: 205*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group2647CV5 (0:897)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // pexelssulimansallehi21281652de (0:899)
                                          padding: EdgeInsets.fromLTRB(1*fem, 1*fem, 1*fem, 0*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xfff3f3f3),
                                          ),
                                          child: Align(
                                            // pexelssulimansallehi21281652US (0:900)
                                            alignment: Alignment.bottomCenter,
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 106*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xfff3f3f3),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-DEf.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame60aVd (0:902)
                                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 4*fem),
                                          width: double.infinity,
                                          height: 66*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                            borderRadius: BorderRadius.only (
                                              bottomRight: Radius.circular(12*fem),
                                              bottomLeft: Radius.circular(12*fem),
                                            ),
                                          ),
                                          child: Container(
                                            // frame119szX (0:903)
                                            width: 109*fem,
                                            height: 43*fem,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // roma2cX (0:904)
                                                  //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont (
                                                      'Nunito',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 2*ffem/fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // weekendrelaxxFH (0:905)
                                                  'Weekend Relax\n',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2666666667*ffem/fem,
                                                    letterSpacing: -0.0450000018*fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646tej (0:907)
                                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 58*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // maskgroupdkj (0:908)
                                          //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-3Mh.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinouTM (0:911)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'TantoSvago',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16*fem,
                    ),
                    Container(
                      // group50599cb (0:912)
                      width: double.infinity,
                      height: 213*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cardvoucher5WF (0:913)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // frame2648AXh (0:914)
                              width: 161*fem,
                              height: 205*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group2647WrT (0:915)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // pexelssulimansallehi21281652de (0:917)
                                          padding: EdgeInsets.fromLTRB(1*fem, 1*fem, 1*fem, 0*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xfff3f3f3),
                                          ),
                                          child: Align(
                                            // pexelssulimansallehi21281652Bh (0:918)
                                            alignment: Alignment.bottomCenter,
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 106*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xfff3f3f3),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-hQ3.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame60ViP (0:920)
                                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 4*fem),
                                          width: double.infinity,
                                          height: 66*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                            borderRadius: BorderRadius.only (
                                              bottomRight: Radius.circular(12*fem),
                                              bottomLeft: Radius.circular(12*fem),
                                            ),
                                          ),
                                          child: Container(
                                            // frame119bmR (0:921)
                                            width: 109*fem,
                                            height: 43*fem,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // romaYwZ (0:922)
                                                  //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont (
                                                      'Nunito',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 2*ffem/fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // weekendrelaxg2B (0:923)
                                                  'Weekend Relax\n',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2666666667*ffem/fem,
                                                    letterSpacing: -0.0450000018*fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646osV (0:925)
                                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 58*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // maskgroupwio (0:926)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-Y6j.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinofPu (0:929)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'TantoSvago',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // cardvoucherzBH (0:930)
                            width: 160*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffeeeeee)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(12*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 9.5*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // frame2648hrP (0:931)
                              width: 161*fem,
                              height: 205*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // group26473fM (0:932)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // pexelssulimansallehi21281652de (0:934)
                                          padding: EdgeInsets.fromLTRB(1*fem, 1*fem, 1*fem, 0*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xfff3f3f3),
                                          ),
                                          child: Align(
                                            // pexelssulimansallehi21281652Hp (0:935)
                                            alignment: Alignment.bottomCenter,
                                            child: SizedBox(
                                              width: double.infinity,
                                              height: 106*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xfff3f3f3),
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/pexels-suliman-sallehi-2128165-2-bg-YH5.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame60zj1 (0:937)
                                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 12*fem, 4*fem),
                                          width: double.infinity,
                                          height: 66*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                            borderRadius: BorderRadius.only (
                                              bottomRight: Radius.circular(12*fem),
                                              bottomLeft: Radius.circular(12*fem),
                                            ),
                                          ),
                                          child: Container(
                                            // frame1195kT (0:938)
                                            width: 109*fem,
                                            height: 43*fem,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // romadGB (0:939)
                                                  //margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                                  child: Text(
                                                    'Roma',
                                                    style: SafeGoogleFont (
                                                      'Nunito',
                                                      fontSize: 10*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 2*ffem/fem,
                                                      color: Color(0xff091125),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // weekendrelax8Tq (0:940)
                                                  'Weekend Relax\n',
                                                  style: SafeGoogleFont (
                                                    'Nunito',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2666666667*ffem/fem,
                                                    letterSpacing: -0.0450000018*fem,
                                                    color: Color(0xff091125),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame2646SDd (0:942)
                                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 58*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // maskgroupZJF (0:943)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mask-group-7XV.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Container(
                                          // hamburgerdibovinorHM (0:946)
                                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                          child: Text(
                                            'TantoSvago',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xff8a94a6),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame5057Mju (0:947)
              left: 0*fem,
              top: 147*fem,
              child: Container(
                width: 942*fem,
                height: 55*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // tagUZd (0:948)
                      left: 0*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 59*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xff2b50b0)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Tutti',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.3625*ffem/fem,
                                letterSpacing: -0.3000000119*fem,
                                color: Color(0xff2b50b0),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagKaF (0:949)
                      left: 58.8999938965*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 96*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Top Brand',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagBcT (0:950)
                      left: 154.799987793*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 80*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Atletica',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagFsD (0:951)
                      left: 234.700012207*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 71*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Danza',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // taguwm (0:952)
                      left: 305.6000061035*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 103*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Soft fitness',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagyRq (0:953)
                      left: 408.5*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 83*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Palestre',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagens (0:954)
                      left: 491.4000244141*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 70*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Nuoto',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagXLs (0:955)
                      left: 561.299987793*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 120*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Centri sportivi',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagNsH (0:956)
                      left: 681.200012207*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 72*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Tennis',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tagqF5 (0:957)
                      left: 753.1000366211*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 109*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Arti Marziali',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tag4tX (0:958)
                      left: 862.0000610352*fem,
                      top: 0*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 80*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd2dcf4)),
                            color: Color(0xfff5f8ff),
                          ),
                          child: Center(
                            child: Text(
                              'Crossfit',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffa1b5e8),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle4704L5M (0:959)
              left: 0*fem,
              top: 92*fem,
              child: Align(
                child: SizedBox(
                  width: 378*fem,
                  height: 55*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffedd5),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // palestreecentrisportiviqH1 (0:960)
              left: 22*fem,
              top: 108*fem,
              child: Align(
                child: SizedBox(
                  width: 199*fem,
                  height: 25*fem,
                  child: Text(
                    'Palestre e centri sportivi',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.3625*ffem/fem,
                      color: Color(0xfff97316),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // appbarunf (0:962)
              left: 0*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 377*fem,
                  height: 48*fem,
                  child: Image.asset(
                    'assets/page-1/images/appbar-j19.png',
                    width: 377*fem,
                    height: 48*fem,
                  ),
                ),
              ),
            ),

            Container(
                alignment: Alignment.bottomCenter,
                // Allinea il contenuto in basso
                child: BottomNavigationBar(
                  items: const <BottomNavigationBarItem>[
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.card_giftcard),
                      label: 'Buoni acquisto',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.bookmarks),
                      label: 'Voucher',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.receipt_long),
                      label: 'Rimborsi',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.payments),
                      label: 'Versamenti',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: Colors.blue,
                  // Colore dell'elemento selezionato
                  onTap: _onItemTapped,
                )

            ),
          ],
        ),
      ),
          );
  }
}