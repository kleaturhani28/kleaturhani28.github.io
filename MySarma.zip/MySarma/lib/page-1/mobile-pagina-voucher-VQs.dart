import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';

class PaginaVoucherVQs extends StatefulWidget {
  @override
  _PaginaVoucherVQs createState() => _PaginaVoucherVQs();
}
class _PaginaVoucherVQs extends State<PaginaVoucherVQs> {int _selectedIndex = 0;

void _onItemTapped(int index) {
  if (index == 0) {
    Navigator.push(context,
      MaterialPageRoute(builder: (context) => MobileStartHomeWelfareCard()),
    );
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // mobilepaginavoucherqmZ (0:1090)
        width: double.infinity,
        height: 814*fem,
        decoration: BoxDecoration (
          color: Color(0xfff5f8ff),
        ),
        child: Stack(
          children: [
            Positioned(
              // group2447MV1 (0:1092)
              left: 0*fem,
              top: 1*fem,
              child: Container(
                width: 398*fem,
                height: 810*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(12*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x0c000000),
                      offset: Offset(0*fem, 0*fem),
                      blurRadius: 9.5*fem,
                    ),
                  ],
                ),
                child: Container(
                  // frame2359qQB (0:1093)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xffe8e8e8)),
                    color: Color(0xffffffff),
                    borderRadius: BorderRadius.circular(12*fem),
                  ),
                  child: Stack(
                    children: [

                      Positioned(
                        // frame2456uKV (0:1094)
                        left: 48.57421875*fem,
                        top: 217.611831665*fem,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(0*fem, 0.02*fem, 0*fem, 0*fem),
                          width: 279*fem,
                          height: 373*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // iconcongratulationsBH1 (0:1095)
                                margin: EdgeInsets.fromLTRB(0.03*fem, 0*fem, 0*fem, 26*fem),
                                width: 160.03*fem,
                                height: 134.98*fem,
                                child: Image.asset(
                                  'assets/page-1/images/iconcongratulations.png',
                                  width: 160.03*fem,
                                  height: 134.98*fem,
                                ),
                              ),
                              Container(
                                // acquistoeffettuatoconsuccesso5 (0:1130)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 26*fem),
                                constraints: BoxConstraints (
                                  maxWidth: 267*fem,
                                ),
                                child: Text(
                                  'Acquisto effettuato con successo',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff333232),
                                  ),
                                ),
                              ),
                              Container(
                                // frame5070NMV (0:1131)
                                margin: EdgeInsets.fromLTRB(1.5*fem, 0*fem, 1.5*fem, 26*fem),
                                padding: EdgeInsets.fromLTRB(32*fem, 7*fem, 32*fem, 6*fem),
                                width: double.infinity,
                                height: 46*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffe6ecf9),
                                  borderRadius: BorderRadius.circular(6*fem),
                                ),
                                child: Center(
                                  // riceveraiunaemailconilvouchere (0:1132)
                                  child: SizedBox(
                                    child: Container(
                                      constraints: BoxConstraints (
                                        maxWidth: 212*fem,
                                      ),
                                      child: Text(
                                        'Riceverai una email con il voucher e le indicazioni per utilizzarlo',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xff426bd1),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group5068vnK (0:1133)
                                width: double.infinity,
                                height: 48*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff2b50b0),
                                  borderRadius: BorderRadius.circular(500*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'Continua ad acquistare',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // appbarQBh (0:1137)
              left: 0*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 377*fem,
                  height: 48*fem,
                  child: Image.asset(
                    'assets/page-1/images/appbar-9BD.png',
                    width: 377*fem,
                    height: 48*fem,
                  ),
                ),
              ),
            ),

            Container(
                alignment: Alignment.bottomCenter,
                // Allinea il contenuto in basso
                child: BottomNavigationBar(
                  items: const <BottomNavigationBarItem>[
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.card_giftcard),
                      label: 'Buoni acquisto',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.bookmarks),
                      label: 'Voucher',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.receipt_long),
                      label: 'Rimborsi',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.payments),
                      label: 'Versamenti',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: Colors.blue,
                  // Colore dell'elemento selezionato
                  onTap: _onItemTapped,
                )

            ),
          ],
        ),
      ),
          );
  }
}