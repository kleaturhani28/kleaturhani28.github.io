
import 'package:flutter/material.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';
import 'package:myapp/page-1/mobile-pagina-voucher.dart';
import 'package:myapp/page-1/mobile-pagina-categoria-voucher.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-B11.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-dPd.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-VQs.dart';

class Routes {
  static const String welfareCard = '/welfare-card';
  static const String paginaVoucher = '/pagina-voucher';
  static const String paginaCategoriaVoucher = '/pagina-categoria-voucher';
  static const String paginaVoucherB11 = '/pagina-voucher-B11';
  static const String paginaVoucherdPd = '/pagina-voucher-dPd';
  static const String paginaVoucherVQs = '/pagina-voucher-VQs';

  static final Map<String, WidgetBuilder> routes = {
    welfareCard: (context) => MobileStartHomeWelfareCard(),
    paginaVoucher: (context) => PaginaVoucher(),
    paginaCategoriaVoucher: (context) => PaginaCategoriaVoucher(),
    paginaVoucherB11: (context) => PaginaVoucherB11(),
    paginaVoucherdPd: (context) => PaginaVoucherdPd(),
    paginaVoucherVQs: (context) => PaginaVoucherVQs(),
  };
}
