import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/mobile-start-home-welfare-card.dart';
import 'package:myapp/page-1/mobile-pagina-voucher.dart';
import 'package:myapp/page-1/mobile-pagina-categoria-voucher.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-B11.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-dPd.dart';
import 'package:myapp/page-1/mobile-pagina-voucher-VQs.dart';
import 'package:myapp/routes.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'MySarma',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		initialRoute: Routes.welfareCard,
		routes: {
			Routes.welfareCard: (context) => MobileStartHomeWelfareCard(),
			Routes.paginaVoucher: (context) => PaginaVoucher(),
			Routes.paginaCategoriaVoucher: (context) => PaginaCategoriaVoucher(),
			Routes.paginaVoucherB11: (context) => PaginaVoucherB11(),
			Routes.paginaVoucherdPd: (context) => PaginaVoucherdPd(),
			Routes.paginaVoucherVQs: (context) => PaginaVoucherVQs(),
		},
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),

		home: Scaffold(
		body: SingleChildScrollView(
			child: MobileStartHomeWelfareCard(),
		),
		),
	);
	}
}


//'/page-1/mobile-start-home-welfare-card': (context) => Scene(),
//'/page-1/mobile-pagina-voucher': (context) => PaginaVoucher(),
//	'/page-1/mobile-pagina-categoria-voucher': (context) => PaginaCategoriaVoucher(),
//	'/page-1/mobile-pagina-voucher-B11': (context) => PaginaVoucher1(),
//	'/page-1/mobile-pagina-voucher-dPd': (context) => PaginaVoucher2(),
//	'/page-1/mobile-pagina-voucher-VQs': (context) => PaginaVoucher3(),
